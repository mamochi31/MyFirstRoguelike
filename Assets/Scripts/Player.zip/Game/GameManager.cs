using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using System.Collections;

/// <summary>
/// ゲームの進行状態（ゲームクリア／ゲームオーバー）を一元管理するクラス
/// プレイヤーや敵、マップ生成後のフローをコントロールします
/// </summary>
public class GameManager : MonoBehaviour
{
    // ✅ Singleton によるインスタンスアクセス
    public static GameManager Instance { get; private set; }

    [Header("ゲームクリア UI")]
    public GameObject clearPanel;               // クリア時に表示するパネル

    [Header("ゲームオーバー UI")]
    public GameObject gameOverPanel;            // ゲームオーバー時に表示するパネル

    [Header("停止対象のプレイヤー")]
    public GameObject player;                   // 操作を止めるプレイヤーオブジェクト

    [Header("ミニマップ")]
    [SerializeField] private MiniMapController miniMapController;                 // ミニマップ生成クラス

    private int enemyCount = 0;                 // 敵の残数
    private bool isGameOver = false;            // ゲームオーバーフラグ




    void Awake()
    {
        // Singletonの初期化
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;

        // UI初期化（非表示）
        if (clearPanel != null) clearPanel.SetActive(false);
        if (gameOverPanel != null) gameOverPanel.SetActive(false);
    }

    void Start()
    {
        // マップが生成されるまで待機し、敵数を数える
        StartCoroutine(WaitForMap());
    }

    /// <summary>
    /// マップ生成完了を待ってからの処理
    /// </summary>
    IEnumerator WaitForMap()
    {
        // マップ生成が完了するまで待機
        yield return new WaitUntil(() =>
            MapGenerator.Instance != null && MapGenerator.Instance.IsGenerated
        );

        // プレイヤーを生成して取得
        player = MapGenerator.Instance.SpawnPlayer();
        // ボスを生成して取得
        GameObject boss = MapGenerator.Instance.SpawnBoss();
        // 敵を生成して数を取得
        enemyCount = MapGenerator.Instance.SpawnEnemies();

        // ミニマップを初期化
        miniMapController.Initialize(MapGenerator.Instance.map, player);
    }

    /// <summary>
    /// 敵が1体倒されたときに呼ばれる（EnemyHealthから）
    /// </summary>
    public void OnEnemyDefeated()
    {
        enemyCount--;
        Debug.Log($"敵が倒された！残り: {enemyCount}");

        if (enemyCount <= 0 && !isGameOver)
        {
            // UI表示
            if (clearPanel != null) clearPanel.SetActive(true);
            Debug.Log("🎉 ゲームクリア！");

            // ゲーム停止
            GameStop();
        }
    }

    /// <summary>
    /// ボスが倒されたときに呼ばれる（EnemyHealthから）
    /// </summary>
    public void TriggerGameClear()
    {
        // UI表示
        Debug.Log("🎉 ボス撃破！ゲームクリア！");
        if (clearPanel != null) clearPanel.SetActive(true);

        // ゲーム停止
        GameStop();
    }

    /// <summary>
    /// プレイヤーが死亡したときに呼ばれる（PlayerHealthから）
    /// </summary>
    public void TriggerGameOver()
    {
        if (isGameOver) return;
        isGameOver = true;

        Debug.Log("☠️ ゲームオーバー");

        // UI表示
        if (gameOverPanel != null) gameOverPanel.SetActive(true);

        // ゲーム停止
        GameStop();
    }

    /// <summary>
    /// ゲームを停止させる
    /// </summary>
    private void GameStop()
    {
        // プレイヤーの操作をすべて止める（MonoBehaviourを無効化）
        if (player != null)
        {
            foreach (var comp in player.GetComponents<MonoBehaviour>())
            {
                comp.enabled = false;
            }
        }

        // 時間停止（必要に応じて）
        Time.timeScale = 0f;
    }

    /// <summary>
    /// ゲームをリトライする
    /// </summary>
    public void Retry()
    {
        Debug.Log("🔁 リトライを実行中...");
        Time.timeScale = 1f; // 一時停止を解除（必要な場合）
        SceneManager.LoadScene(SceneManager.GetActiveScene().name); // 現在のシーンを再読み込み
    }
}
