using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// ミニマップを生成して RawImage に表示する
/// </summary>
public class MiniMapController : MonoBehaviour
{
    public RawImage miniMapImage; // UIに配置した RawImage
    public int pixelPerTile = 4;  // 1タイル = 4ピクセル角など
    public Color wallColor = Color.black;
    public Color floorColor = Color.gray;
    public Color corridorColor = Color.gray;
    public Color playerColor = Color.red;

    private Texture2D texture;
    private MapData mapData;
    private GameObject player;

    public void Initialize(MapData map, GameObject playerObj)
    {
        mapData = map;
        player = playerObj;

        int w = map.Width * pixelPerTile;
        int h = map.Height * pixelPerTile;
        texture = new Texture2D(w, h);
        texture.filterMode = FilterMode.Point;

        miniMapImage.texture = texture;

        RedrawMap();
    }

    void Update()
    {
        if (mapData == null || player == null) return;
        RedrawMap();
    }

    void RedrawMap()
    {
        for (int x = 0; x < mapData.Width; x++)
        {
            for (int y = 0; y < mapData.Height; y++)
            {
                Color c = mapData.GetTile(x, y) == MapData.TileType.Floor || mapData.GetTile(x, y) == MapData.TileType.Corridor ? floorColor : wallColor;
                FillTile(x, y, c);
            }
        }

        // プレイヤーの位置を描画（マップ上座標に変換）
        Vector3 world = player.transform.position;
        Vector3Int cell = MapGenerator.Instance.floorTilemap.WorldToCell(world);
        FillTile(cell.x, cell.y, playerColor);

        texture.Apply();
    }

    void FillTile(int tileX, int tileY, Color color)
    {
        int px = tileX * pixelPerTile;
        int py = tileY * pixelPerTile;

        for (int dx = 0; dx < pixelPerTile; dx++)
        {
            for (int dy = 0; dy < pixelPerTile; dy++)
            {
                texture.SetPixel(px + dx, py + dy, color);
            }
        }
    }
}
